#!/usr/bin/python2

import os
import shutil
import commands
import urllib
import re
urlread = lambda url: urllib.urlopen(url).read()

def copycover(currentalbum, src, dest, defaultfile):
    _doubanSearchApi    = 'http://www.douban.com/subject_search?search_text={0}&cat=1003'
    _doubanCoverPattern = '<img src="http://img3.douban.com/spic/s(\d+).jpg"'
    _doubanConverAddr   = 'http://img3.douban.com/lpic/s{0}.jpg'
    searchstring = urllib.quote(currentalbum)
    
    if not os.path.exists(src):
        request = _doubanSearchApi.format(searchstring)
        result = urlread(request)
        match = re.compile(_doubanCoverPattern, re.IGNORECASE).search(result)
        if match:
            image = _doubanConverAddr.format(match.groups()[0])
            urllib.urlretrieve(image, src)
    
    if os.path.exists(src):
        shutil.copy(src, dest)
    elif os.path.exists(defaultfile):
        shutil.copy(defaultfile, dest)
    else:
        print ""

# Path where the images are saved
imgpath = os.getenv("HOME") + "/.covers/"

# image displayed when no image found
noimg = imgpath + "nocover.png"

# Cover displayed by conky
cover = "/tmp/cover"

# Name of current album
album = commands.getoutput("mpc --format %artist%\ %album% | head -n 1")

# If tags are empty, use noimg.
if album == "":
    if os.path.exists(conkycover):
        os.remove(conkycover)
    if os.path.exists(noimg):
        shutil.copy(noimg, conkycover)
    else:
        print ""
else:

    filename = imgpath + album + ".jpg"
    if os.path.exists("/tmp/nowplaying") and os.path.exists("/tmp/cover"):
        nowplaying = open("/tmp/nowplaying").read()
        if nowplaying == album:
            pass
        else:
            copycover(album, filename, cover, noimg)
            open("/tmp/nowplaying", "w").write(album)
    else:
        copycover(album, filename, cover, noimg)
        open("/tmp/nowplaying", "w").write(album)
